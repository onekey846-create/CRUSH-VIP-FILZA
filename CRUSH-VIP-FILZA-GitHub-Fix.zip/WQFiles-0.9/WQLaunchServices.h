//
//  WQLaunchServices.h
//  WQ Files
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Human app name for a bundle id, from LaunchServices' database (read from
// lsd's container), a built-in table of Apple services, or the parent app.
NSString *_Nullable wq_display_name(NSString *_Nullable bundleID);

// Bundle id of an app or extension data container (/private/var/mobile/
// Containers/Data/...), from the same LaunchServices database. For iOS 27.2,
// where the containers' identifier attribute can't be read. Nil if unknown.
NSString *_Nullable wq_bundle_id_for_container(NSString *path);

// Whether the name database is loaded; loading it (blocking, off the main
// thread) the first time can take a while, so screens show a status for it.
BOOL wq_display_names_loaded(void);
void wq_load_display_names(void);
// After a user's refresh: search for a database that wasn't found before
// right away instead of waiting a day.
void wq_display_names_reset_miss(void);
// Every app and extension data container the LaunchServices database lists,
// read from storeHint (remembered when it parses) or the remembered location.
// Never scans. Nil when there's no usable database.
NSArray<NSString *> *_Nullable wq_ls_container_paths(NSString *_Nullable storeHint);
// The .app bundle of an installed app, from the same database (for icons
// where iOS won't hand them out). Nil if unknown.
NSString *_Nullable wq_bundle_path_for_id(NSString *bundleID);

NS_ASSUME_NONNULL_END
